# godot_racing
Example racing game for coderdojo

Play online at https://electronstudio.github.io/godot_racing/

# Credits

Graphics
* https://www.kenney.nl/assets/racing-pack
Sound:
* https://opengameart.org/content/car-tire-squeal-skid-loop
* https://opengameart.org/content/crash-collision
* https://opengameart.org/content/car-engine-loop-96khz-4s
